var x = 0;
var images = [];
var time = 1000;

images[0]="1.jpg";
images[1]="2.jpg";
images[2]="3.jpg";

function changeImg()
{
    document.slide.src = images[x];
    if(x<images.length - 1)
    {
        x++;
    }
    else
    {
        x=0;
    }
    setTimeout("changeImg()",time);
}
window.onload = changeImg;