function formValidation()
{
var CNid = document.registration.CName;
var DOB = document.registration.dob;
var passid = document.registration.passid;
var uname = document.registration.username;
{
if(allLetter(CNid))
{
if(userid_validation(uname,8))
{
if(passid_validation(passid,8,16))
{ 
if(alphanumeric(uname))
{
if(date_validation(DOB))
{
if(submit())
{
}
}
}
}
}
}
}
return false;

} 
function userid_validation(uname,mx)
{
var uname_len = uname.value.length;
if (uname_len == 0 || uname_len > mx)
{ 
alert("Username should be "+mx+" characters");
uname.focus();
return false;
}
return true;
}
function passid_validation(passid,mx,my)
{
var passid_len = passid.value.length;
if (passid_len == 0 ||passid_len >= my || passid_len < mx)
{
alert("Password should not be empty / length be between "+mx+" to "+my);
passid.focus();
return false;
}
return true;
}
function allLetter(CNid)
{ 
var letters = /^[A-Za-z]+$/;
if(CNid.value.match(letters))
{
return true;
}
else
{
alert('Name must have alphabet characters only');
CNid.focus();
return false;
}
}
function alphanumeric(uname)
{ 
var letters = /^[0-9a-zA-Z]+$/;
if(uname.value.match(letters))
{
return true;
}
else
{
alert('Username must have alphanumeric characters only');
uname.focus();
return false;
}
}
function date_validation(DOB)
{
const dateInput = document.getElementById('date');
if(!dateInput.value){
alert('date is invalid');
return false;
  }
else
{
    alert('Form Succesfully Submitted');
    window.location.reload()
    return true;
    }
}

