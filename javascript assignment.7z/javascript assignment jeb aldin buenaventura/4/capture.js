function PIN(){
var name = document.getElementById('input1').value;
var DOB = document.getElementById('input2').value;
var phone = document.getElementById('input3').value;
let upper = name.toUpperCase();

var resultText = "";
result.innerHTML = resultText.concat('PIN: ', upper.substring(0, 4), ' ', DOB.substring(0, 6), ' ', phone.slice(-5));
}