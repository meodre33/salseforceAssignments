function storeSearch()
{
    var x= document.getElementById("search-box").value;
    console.log(x);
}